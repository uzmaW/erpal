See the 7.x-1.x branch.
