<span class="<?php print $flag_wrapper_classes; ?>">
   <span class="<?php print $flag_classes ?>"><?php print $link_text; ?></span>
</span>
